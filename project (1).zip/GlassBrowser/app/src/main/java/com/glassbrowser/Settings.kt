package com.glassbrowser

import android.content.Context
import androidx.compose.animation.core.SpringSpec
import androidx.compose.animation.core.spring
import androidx.compose.runtime.mutableStateMapOf
import kotlin.math.roundToInt

enum class K { SLIDER, TOGGLE, CHOICE }

class P(
    val key: String,
    val group: String,
    val label: String,
    val def: Float,
    val min: Float = 0f,
    val max: Float = 1f,
    val kind: K = K.SLIDER,
    val opts: List<String> = emptyList(),
    val unit: String = "",
    val step: Float = 0f
)

/** Все настройки приложения. Чтобы добавить новую — добавьте строку сюда, экран настроек подхватит её сам. */
val PARAMS = listOf(
    // ---------- Стекло ----------
    P("real", "Стекло", "Реальное размытие фона (Android 12+)", 1f, kind = K.TOGGLE),
    P("blur", "Стекло", "Размытие фона", 18f, 0f, 50f, unit = "dp"),
    P("tint", "Стекло", "Плотность заливки (0 = прозрачное)", 0.22f, 0f, 0.9f),
    P("sat", "Стекло", "Насыщенность цветов под стеклом", 1.8f, 0.5f, 3.5f),
    P("refr", "Стекло", "Преломление по краям (Android 13+)", 12f, 0f, 40f, unit = "dp"),
    P("edgeW", "Стекло", "Ширина зоны преломления", 20f, 4f, 60f, unit = "dp"),
    P("shadow", "Стекло", "Тень", 0.5f, 0f, 1f),
    // ---------- Свет ----------
    P("rim", "Свет и блики", "Яркость светящегося края", 0.7f, 0f, 1f),
    P("rimW", "Свет и блики", "Толщина края", 1.2f, 0.4f, 4f, unit = "dp"),
    P("sheen", "Свет и блики", "Верхний блик", 0.5f, 0f, 1f),
    P("spec", "Свет и блики", "Блик под пальцем", 0.7f, 0f, 1f),
    P("specR", "Свет и блики", "Размер блика под пальцем", 90f, 30f, 220f, unit = "dp"),
    // ---------- Панель ----------
    P("bottom", "Панель", "Панель снизу (выкл. = сверху)", 1f, kind = K.TOGGLE),
    P("barH", "Панель", "Высота панели", 54f, 40f, 76f, unit = "dp"),
    P("barM", "Панель", "Отступ от краёв экрана", 14f, 0f, 32f, unit = "dp"),
    P("gap", "Панель", "Расстояние между кнопками", 8f, 2f, 20f, unit = "dp"),
    P("auto", "Панель", "Сворачивать при прокрутке", 1f, kind = K.TOGGLE),
    P("cw", "Панель", "Ширина свёрнутой панели", 0.56f, 0.3f, 0.9f),
    P("ch", "Панель", "Высота свёрнутой панели", 34f, 24f, 48f, unit = "dp"),
    // ---------- Анимации ----------
    P("speed", "Анимации", "Общая скорость", 1f, 0.5f, 2f),
    P("stiff", "Анимации", "Жёсткость пружины", 420f, 100f, 1500f),
    P("damp", "Анимации", "Упругость (меньше = сильнее отскок)", 0.72f, 0.3f, 1f),
    P("squash", "Анимации", "Липкость: растяжение при движении", 0.7f, 0f, 1.5f),
    P("press", "Анимации", "Увеличение при нажатии", 1.08f, 1f, 1.3f),
    // ---------- Вкладки ----------
    P("cols", "Окно вкладок", "Колонок", 2f, 1f, 3f, step = 1f),
    P("tabR", "Окно вкладок", "Скругление карточек", 26f, 6f, 44f, unit = "dp"),
    P("tabAsp", "Окно вкладок", "Пропорции карточки (ширина/высота)", 0.72f, 0.5f, 1.2f),
    P("tabGap", "Окно вкладок", "Расстояние между карточками", 14f, 4f, 30f, unit = "dp"),
    P("tabDim", "Окно вкладок", "Затемнение фона", 0.35f, 0f, 0.85f),
    // ---------- Меню ----------
    P("menuR", "Меню", "Скругление меню", 30f, 12f, 44f, unit = "dp"),
    P("menuW", "Меню", "Ширина меню", 250f, 200f, 340f, unit = "dp"),
    // ---------- Страницы ----------
    P("theme", "Браузер", "Тема", 0f, kind = K.CHOICE, opts = listOf("Системная", "Светлая", "Тёмная")),
    P("engine", "Браузер", "Поисковик", 0f, kind = K.CHOICE, opts = listOf("Google", "DuckDuckGo", "Яндекс", "Bing")),
    P("desktop", "Браузер", "Версия сайтов для ПК", 0f, kind = K.TOGGLE),
    P("js", "Браузер", "JavaScript", 1f, kind = K.TOGGLE),
    P("pad", "Браузер", "Отступ снизу страницы под панель", 1f, kind = K.TOGGLE)
)

class S(ctx: Context) {
    private val sp = ctx.getSharedPreferences("glass_settings", Context.MODE_PRIVATE)
    private val m = mutableStateMapOf<String, Float>().apply {
        PARAMS.forEach { put(it.key, sp.getFloat(it.key, it.def)) }
    }

    operator fun get(k: String): Float = m[k] ?: 0f
    operator fun set(k: String, v: Float) {
        m[k] = v
        sp.edit().putFloat(k, v).apply()
    }

    fun b(k: String): Boolean = get(k) > 0.5f
    fun i(k: String): Int = get(k).roundToInt()

    fun reset(group: String? = null) {
        PARAMS.filter { group == null || it.group == group }.forEach { set(it.key, it.def) }
    }

    /** Пружина по настройкам пользователя — используется всеми анимациями. */
    fun springF(): SpringSpec<Float> = spring(
        dampingRatio = get("damp").coerceIn(0.2f, 1f),
        stiffness = (get("stiff") * get("speed")).coerceAtLeast(60f)
    )
}
