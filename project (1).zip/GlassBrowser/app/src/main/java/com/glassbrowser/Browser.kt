package com.glassbrowser

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap

fun hostOf(u: String): String = try {
    Uri.parse(u).host?.removePrefix("www.") ?: u
} catch (e: Exception) {
    u
}

class Tab(val id: Int, u: String = "") {
    var url by mutableStateOf(u)
    var title by mutableStateOf("")
    var progress by mutableFloatStateOf(0f)
    var loading by mutableStateOf(false)
    var canBack by mutableStateOf(false)
    var canFwd by mutableStateOf(false)
    var thumb by mutableStateOf<ImageBitmap?>(null)
    var web: WebView? = null
    val label: String get() = if (url.isEmpty()) "Избранное" else title.ifEmpty { hostOf(url) }
}

class Browser(private val ctx: Context, val s: S) {
    private val sp = ctx.getSharedPreferences("browser", Context.MODE_PRIVATE)
    val tabs = mutableStateListOf<Tab>()
    var cur by mutableIntStateOf(0)
    var collapsed by mutableStateOf(false)
    var env: GlassEnv? = null
    val bookmarks = mutableStateListOf<String>()
    val history = mutableStateListOf<String>()
    private var nextId = 1
    val current: Tab get() = tabs[cur]
    val isBookmarked: Boolean get() = current.url.isNotEmpty() && bookmarks.contains(current.url)

    init {
        bookmarks.addAll(sp.getString("bm", "")!!.split("\n").filter { it.isNotBlank() })
        history.addAll(sp.getString("hist", "")!!.split("\n").filter { it.isNotBlank() })
        val saved = sp.getString("tabs", "")!!.split("\n").filter { it.isNotBlank() }
        if (saved.isEmpty()) tabs.add(Tab(nextId++))
        else saved.forEach { tabs.add(Tab(nextId++, if (it == "-") "" else it)) }
        cur = sp.getInt("cur", 0).coerceIn(0, tabs.size - 1)
    }

    fun save() {
        sp.edit()
            .putString("tabs", tabs.joinToString("\n") { it.url.ifEmpty { "-" } })
            .putInt("cur", cur)
            .putString("bm", bookmarks.joinToString("\n"))
            .putString("hist", history.take(100).joinToString("\n"))
            .apply()
    }

    fun newTab(url: String = "") {
        tabs.add(cur + 1, Tab(nextId++, url))
        cur += 1
        collapsed = false
        save()
    }

    fun openInNewTab(url: String) {
        if (current.url.isEmpty()) navigate(url) else newTab(toUrl(url))
    }

    fun select(i: Int) {
        cur = i.coerceIn(0, tabs.size - 1)
        collapsed = false
        save()
    }

    fun closeTab(id: Int) {
        val i = tabs.indexOfFirst { it.id == id }
        if (i < 0) return
        tabs[i].web?.let { (it.parent as? ViewGroup)?.removeView(it); it.destroy() }
        tabs.removeAt(i)
        if (tabs.isEmpty()) {
            tabs.add(Tab(nextId++)); cur = 0
        } else {
            if (i < cur) cur -= 1
            cur = cur.coerceIn(0, tabs.size - 1)
        }
        save()
    }

    fun toUrl(q: String): String {
        val t = q.trim()
        if (t.isEmpty()) return ""
        if (t.startsWith("http://") || t.startsWith("https://") || t.startsWith("file://") || t.startsWith("about:")) return t
        if (!t.contains(' ') && (t.contains('.') || t.startsWith("localhost"))) return "https://$t"
        val e = Uri.encode(t)
        return when (s.i("engine")) {
            0 -> "https://www.google.com/search?q=$e"
            1 -> "https://duckduckgo.com/?q=$e"
            2 -> "https://yandex.ru/search/?text=$e"
            else -> "https://www.bing.com/search?q=$e"
        }
    }

    fun navigate(input: String) {
        val u = toUrl(input)
        if (u.isEmpty()) return
        val t = current
        val had = t.web != null
        t.url = u
        val w = webFor(t)
        if (had) w.loadUrl(u)
        collapsed = false
        save()
    }

    fun toggleBookmark() {
        val u = current.url
        if (u.isEmpty()) return
        if (!bookmarks.remove(u)) bookmarks.add(0, u)
        save()
    }

    fun applyDesktop() {
        tabs.forEach { t -> t.web?.settings?.userAgentString = ua() }
        current.web?.reload()
    }

    fun share() {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, current.url)
        }
        ctx.startActivity(Intent.createChooser(i, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun ua(): String? =
        if (s.b("desktop"))
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        else null

    private fun onScroll(t: Tab, y: Int, dy: Int) {
        if (tabs.getOrNull(cur) !== t) return
        if (s.b("auto")) {
            if (dy > 8 && y > 120) collapsed = true
            else if (dy < -8 || y < 40) collapsed = false
        }
        env?.bump()
    }

    @SuppressLint("SetJavaScriptEnabled")
    fun webFor(t: Tab): WebView {
        t.web?.let { return it }
        val w = WebView(ctx)
        w.settings.apply {
            javaScriptEnabled = s.b("js")
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = ua()
        }
        w.webViewClient = object : WebViewClient() {
            override fun onPageStarted(v: WebView, url: String, f: Bitmap?) {
                t.url = url; t.loading = true; t.progress = 0.05f
                t.canBack = v.canGoBack(); t.canFwd = v.canGoForward()
                env?.bump()
            }

            override fun onPageFinished(v: WebView, url: String) {
                t.url = url; t.loading = false; t.title = v.title ?: ""
                t.canBack = v.canGoBack(); t.canFwd = v.canGoForward()
                if (url.startsWith("http")) {
                    history.remove(url); history.add(0, url)
                    if (history.size > 100) history.removeAt(history.size - 1)
                }
                if (s.b("pad") && s.b("js")) v.evaluateJavascript(
                    "(function(){if(!document.getElementById('__gb')&&document.head){var e=document.createElement('style');e.id='__gb';e.textContent='body{padding-bottom:96px !important}';document.head.appendChild(e)}})()",
                    null
                )
                save(); env?.bump()
            }

            override fun doUpdateVisitedHistory(v: WebView, url: String, isReload: Boolean) {
                t.canBack = v.canGoBack(); t.canFwd = v.canGoForward()
                if (url.isNotEmpty()) t.url = url
            }

            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val sc = r.url.scheme ?: return false
                if (sc == "http" || sc == "https" || sc == "about" || sc == "file" || sc == "data" || sc == "blob" || sc == "javascript") return false
                try {
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, r.url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                }
                return true
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                t.progress = p / 100f; env?.bump()
            }

            override fun onReceivedTitle(v: WebView, title: String?) {
                t.title = title ?: ""
            }
        }
        w.setOnScrollChangeListener { _, _, y, _, oy -> onScroll(t, y, y - oy) }
        if (t.url.isNotEmpty()) w.loadUrl(t.url)
        t.web = w
        return w
    }

    /** Снимок текущей страницы для карточки в окне вкладок. */
    fun captureCurrent() {
        val t = current
        val v = t.web ?: return
        if (v.width <= 0 || v.height <= 0 || t.url.isEmpty()) return
        try {
            val w = 480
            val sc = w.toFloat() / v.width
            val bmp = Bitmap.createBitmap(w, (v.height * sc).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            c.scale(sc, sc)
            v.draw(c)
            t.thumb = bmp.asImageBitmap()
        } catch (e: Throwable) {
        }
    }
}
