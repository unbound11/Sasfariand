package com.glassbrowser

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyGridItemScope
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sign
import kotlin.math.sin

val ACCENT = Color(0xFF0A84FF)

val CARD_GRADS = listOf(
    listOf(Color(0xFFFF9A5A), Color(0xFFFF4F8B)),
    listOf(Color(0xFF4FACFE), Color(0xFF00E6B8)),
    listOf(Color(0xFF6C5CFF), Color(0xFF9C7BFF)),
    listOf(Color(0xFFF6C453), Color(0xFFFB7A5A)),
    listOf(Color(0xFF11998E), Color(0xFF38EF7D)),
    listOf(Color(0xFFA18CD1), Color(0xFFFBC2EB))
)

@Composable
fun App(b: Browser, s: S) {
    val sys = androidx.compose.foundation.isSystemInDarkTheme()
    val dark = when (s.i("theme")) {
        1 -> false
        2 -> true
        else -> sys
    }
    val env = rememberGlassEnv(s, dark)
    SideEffect { b.env = env }
    val act = LocalContext.current as ComponentActivity
    DisposableEffect(dark) {
        val tr = android.graphics.Color.TRANSPARENT
        act.enableEdgeToEdge(
            statusBarStyle = if (dark) SystemBarStyle.dark(tr) else SystemBarStyle.light(tr, tr),
            navigationBarStyle = if (dark) SystemBarStyle.dark(tr) else SystemBarStyle.light(tr, tr)
        )
        onDispose { }
    }
    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        CompositionLocalProvider(LocalGlass provides env) { Root(b, s, dark) }
    }
}

@Composable
fun Root(b: Browser, s: S, dark: Boolean) {
    val env = LocalGlass.current
    val d = LocalDensity.current
    val pageBg = if (dark) Color(0xFF0D0D11) else Color.White
    val rootBg = if (dark) Color(0xFF050507) else Color(0xFFD9DBE3)
    var switcher by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val p by animateFloatAsState(if (switcher) 1f else 0f, s.springF(), label = "switcher")
    val sp by animateFloatAsState(if (settings) 1f else 0f, s.springF(), label = "settings")
    val slots = remember { mutableStateMapOf<Int, Rect>() }
    val grid = rememberLazyGridState()
    val statusH = WindowInsets.statusBars.getTop(d)
    val bottom = s.b("bottom")
    val barDp = s["barH"].dp
    val barM = s["barM"].dp
    val topPad = if (bottom) statusH.toFloat() else statusH + with(d) { (barDp + barM * 2).toPx() }

    LaunchedEffect(switcher) {
        if (switcher) {
            val c = s.i("cols").coerceAtLeast(1)
            grid.scrollToItem((b.cur - b.cur % c).coerceAtLeast(0))
        }
    }
    BackHandler(enabled = settings || switcher || menu || editing || b.current.canBack) {
        when {
            settings -> settings = false
            switcher -> switcher = false
            menu -> menu = false
            editing -> editing = false
            else -> b.current.web?.goBack()
        }
    }

    BoxWithConstraints(
        Modifier.fillMaxSize().drawBehind {
            drawRect(rootBg)
            drawRect(Color.Black.copy(alpha = s["tabDim"] * p.coerceIn(0f, 1f)))
        }
    ) {
        val W = with(d) { maxWidth.toPx() }
        val H = with(d) { maxHeight.toPx() }
        val cur = b.current
        val rect = slots[cur.id] ?: Rect(W * 0.28f, H * 0.25f, W * 0.72f, H * 0.25f + W * 0.44f / s["tabAsp"].coerceAtLeast(0.3f))
        val tabR = with(d) { s["tabR"].dp.toPx() }

        // ---------- Страница (живой WebView; при открытии вкладок сжимается в свою карточку) ----------
        Box(
            Modifier.fillMaxSize().graphicsLayer {
                val sc = lerp(1f, rect.width / W, p)
                transformOrigin = TransformOrigin(0f, 0f)
                scaleX = sc; scaleY = sc
                translationX = lerp(0f, rect.left, p)
                translationY = lerp(0f, rect.top, p)
                val visH = lerp(H, rect.height, p) / sc
                val r = lerp(0f, tabR, p) / sc
                shape = object : Shape {
                    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline =
                        Outline.Rounded(RoundRect(0f, 0f, size.width, visH, CornerRadius(r)))
                }
                clip = true
                alpha = 1f - ((p - 0.9f) / 0.1f).coerceIn(0f, 1f)
            }
        ) {
            Box(Modifier.fillMaxSize().glassSource(env).background(pageBg)) {
                if (cur.url.isEmpty()) {
                    StartPage(b, dark, with(d) { topPad.toDp() })
                } else {
                    key(cur.id) {
                        AndroidView(
                            factory = { c -> FrameLayout(c) },
                            update = { fl ->
                                val w = b.webFor(cur)
                                if (w.parent !== fl) {
                                    (w.parent as? ViewGroup)?.removeView(w)
                                    fl.removeAllViews()
                                    fl.addView(w, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                                }
                            },
                            modifier = Modifier.fillMaxSize().padding(top = with(d) { topPad.toDp() })
                        )
                    }
                }
                Box(
                    Modifier.fillMaxWidth().height(with(d) { (statusH + 6).toDp() })
                        .background(Brush.verticalGradient(listOf(pageBg.copy(alpha = 0.9f), Color.Transparent)))
                )
            }
        }

        // ---------- Окно вкладок ----------
        if (p > 0.002f || switcher) {
            Overview(
                b, s, dark, p, slots, grid, switcher,
                onPick = { i -> b.select(i); switcher = false },
                onNew = { b.newTab(); switcher = false },
                onDone = { switcher = false }
            )
        }

        // ---------- Затемнение под меню / строкой поиска ----------
        if (menu || editing) {
            Box(
                Modifier.fillMaxSize().clickable(
                    interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                    indication = null
                ) { menu = false; editing = false }
            )
        }

        // ---------- Панель ----------
        if (p < 0.98f) {
            Box(
                Modifier.fillMaxSize()
                    .graphicsLayer {
                        alpha = (1f - p * 1.6f).coerceIn(0f, 1f)
                        translationY = (if (bottom) 1f else -1f) * p * 90f
                    }
                    .then(if (bottom) Modifier.navigationBarsPadding().imePadding() else Modifier.statusBarsPadding())
                    .padding(vertical = barM)
            ) {
                MenuPanel(
                    b, s, dark, menu, bottom,
                    Modifier.align(if (bottom) Alignment.BottomEnd else Alignment.TopEnd)
                        .padding(horizontal = barM, vertical = barDp + s["gap"].dp),
                    onClose = { menu = false },
                    onTabs = { editing = false; b.captureCurrent(); switcher = true },
                    onSettings = { settings = true }
                )
                Column(Modifier.align(if (bottom) Alignment.BottomCenter else Alignment.TopCenter)) {
                    if (bottom) {
                        Suggest(b, s, dark, editing, query, bottom) { q -> editing = false; b.navigate(q) }
                        Spacer(Modifier.height(s["gap"].dp))
                    }
                    Bar(
                        b, s, dark, editing, query,
                        onQuery = { query = it },
                        onEdit = { e -> editing = e; if (e) { query = b.current.url; menu = false } },
                        onSubmit = { q -> editing = false; b.navigate(q) },
                        onMenu = { editing = false; menu = !menu }
                    )
                    if (!bottom) {
                        Spacer(Modifier.height(s["gap"].dp))
                        Suggest(b, s, dark, editing, query, bottom) { q -> editing = false; b.navigate(q) }
                    }
                }
            }
        }

        // ---------- Настройки ----------
        if (sp > 0.002f || settings) {
            Box(
                Modifier.fillMaxSize().graphicsLayer {
                    translationY = (1f - sp) * H
                    alpha = sp.coerceIn(0f, 1f)
                }
            ) {
                SettingsScreen(s, dark) { settings = false }
            }
        }
    }
}

@Composable
fun Bar(
    b: Browser, s: S, dark: Boolean, editing: Boolean, query: String,
    onQuery: (String) -> Unit, onEdit: (Boolean) -> Unit, onSubmit: (String) -> Unit, onMenu: () -> Unit
) {
    val d = LocalDensity.current
    val ink = if (dark) Color.White else Color(0xFF16161A)
    val barH = s["barH"].dp
    val focus = LocalFocusManager.current
    val c = remember { Animatable(0f) }
    val collapse = b.collapsed && !editing
    LaunchedEffect(collapse, s["stiff"], s["damp"], s["speed"]) { c.animateTo(if (collapse) 1f else 0f, s.springF()) }
    val e by animateFloatAsState(if (editing) 1f else 0f, s.springF(), label = "edit")
    val tab = b.current
    val prog by animateFloatAsState(if (tab.loading) tab.progress.coerceIn(0.06f, 1f) else 1f, tween(260), label = "prog")
    val progA by animateFloatAsState(if (tab.loading) 1f else 0f, tween(350), label = "progA")

    BoxWithConstraints(Modifier.fillMaxWidth().padding(horizontal = s["barM"].dp).height(barH)) {
        val W = with(d) { maxWidth.toPx() }
        val bh = with(d) { barH.toPx() }
        val g = with(d) { s["gap"].dp.toPx() }
        val cwPx = W * s["cw"]
        val chPx = with(d) { s["ch"].dp.toPx() }
        val cc = c.value
        val ee = e.coerceIn(0f, 1f)

        val pl = lerp(lerp(bh + g, (W - cwPx) / 2f, cc), 0f, ee)
        val pw = lerp(lerp(W - 2f * (bh + g), cwPx, cc), W, ee)
        val ph = lerp(bh, chPx, cc * (1f - ee))
        val sideA = (1f - cc * 1.7f).coerceIn(0f, 1f) * (1f - ee)
        val sideSc = lerp(1f, 0.4f, cc)

        // Назад (долгое нажатие — вперёд)
        if (sideA > 0.02f) {
            Glass(
                Modifier.offset { IntOffset(lerp(0f, (W - cwPx) / 2f, cc).roundToInt() - (ee * 40.dp.toPx()).roundToInt(), 0) }
                    .size(barH).graphicsLayer { alpha = sideA; scaleX = sideSc; scaleY = sideSc },
                corner = barH / 2,
                onClick = { if (tab.canBack) tab.web?.goBack() },
                onLongClick = { if (tab.canFwd) tab.web?.goForward() }
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = ink.copy(alpha = if (tab.canBack) 1f else 0.35f))
            }
        }
        // Меню
        if (sideA > 0.02f) {
            Glass(
                Modifier.offset { IntOffset((W - bh - lerp(0f, (W - cwPx) / 2f, cc) + (ee * 40.dp.toPx())).roundToInt(), 0) }
                    .size(barH).graphicsLayer { alpha = sideA; scaleX = sideSc; scaleY = sideSc },
                corner = barH / 2, onClick = onMenu
            ) {
                Icon(Icons.Filled.MoreVert, null, Modifier.rotate(90f), tint = ink)
            }
        }
        // Адресная «таблетка» — растягивается и сплющивается по скорости пружины
        Glass(
            Modifier.offset { IntOffset(pl.roundToInt(), ((bh - ph) / 2f).roundToInt()) }
                .size(with(d) { pw.toDp() }, with(d) { ph.toDp() })
                .graphicsLayer {
                    val q = (abs(c.velocity) * 0.012f * s["squash"]).coerceAtMost(0.16f)
                    scaleX = 1f + q; scaleY = 1f - q * 0.85f
                },
            corner = with(d) { (ph / 2f).toDp() },
            onClick = { if (b.collapsed) b.collapsed = false else if (!editing) onEdit(true) }
        ) {
            Box(Modifier.fillMaxSize()) {
                Text(
                    "aA", Modifier.align(Alignment.CenterStart).padding(start = 16.dp)
                        .graphicsLayer { alpha = (1f - cc) * (1f - ee) },
                    color = ink.copy(alpha = 0.8f), fontSize = 15.sp, fontWeight = FontWeight.SemiBold
                )
                Icon(
                    Icons.Filled.Search, null,
                    Modifier.align(Alignment.CenterStart).padding(start = 14.dp).size(20.dp).graphicsLayer { alpha = ee },
                    tint = ink.copy(alpha = 0.7f)
                )
                if (editing) {
                    var tf by remember { mutableStateOf(TextFieldValue(tab.url, TextRange(0, tab.url.length))) }
                    val fr = remember { FocusRequester() }
                    LaunchedEffect(Unit) { delay(60); fr.requestFocus() }
                    BasicTextField(
                        value = tf,
                        onValueChange = { tf = it; onQuery(it.text) },
                        singleLine = true,
                        textStyle = TextStyle(color = ink, fontSize = 16.sp),
                        cursorBrush = SolidColor(ACCENT),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(onGo = { focus.clearFocus(); onSubmit(tf.text) }),
                        modifier = Modifier.align(Alignment.CenterStart).fillMaxWidth()
                            .padding(start = 44.dp, end = 14.dp).focusRequester(fr)
                    )
                } else {
                    Text(
                        if (tab.url.isEmpty()) "Поиск или адрес сайта" else hostOf(tab.url),
                        Modifier.align(Alignment.Center).padding(horizontal = 40.dp),
                        color = ink.copy(alpha = if (tab.url.isEmpty()) 0.55f else 0.95f),
                        fontSize = lerp(16f, 13f, cc).sp, fontWeight = FontWeight.Medium,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    Box(
                        Modifier.align(Alignment.CenterEnd).size(44.dp)
                            .graphicsLayer { alpha = (1f - cc) * (1f - ee) }
                            .clip(CircleShape)
                            .clickable(enabled = cc < 0.5f && tab.url.isNotEmpty()) {
                                if (tab.loading) tab.web?.stopLoading() else tab.web?.reload()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (tab.url.isNotEmpty())
                            Icon(if (tab.loading) Icons.Filled.Close else Icons.Filled.Refresh, null, Modifier.size(18.dp), tint = ink.copy(alpha = 0.8f))
                    }
                }
                Box(
                    Modifier.align(Alignment.BottomStart).fillMaxWidth(prog).height(2.5.dp)
                        .graphicsLayer { alpha = progA }.background(ACCENT)
                )
            }
        }
    }
}

class MI(val icon: ImageVector, val label: String, val act: () -> Unit)

@Composable
fun MenuPanel(
    b: Browser, s: S, dark: Boolean, open: Boolean, bottom: Boolean, modifier: Modifier,
    onClose: () -> Unit, onTabs: () -> Unit, onSettings: () -> Unit
) {
    val m by animateFloatAsState(if (open) 1f else 0f, s.springF(), label = "menu")
    if (m < 0.01f && !open) return
    val ink = if (dark) Color.White else Color(0xFF16161A)
    val items = listOf(
        MI(Icons.Filled.Add, "Новая вкладка") { b.newTab(); onClose() },
        MI(Icons.Filled.Menu, "Показать вкладки") { onClose(); onTabs() },
        MI(Icons.Filled.Share, "Поделиться") { onClose(); b.share() },
        MI(Icons.Filled.Star, if (b.isBookmarked) "Убрать из закладок" else "В закладки") { b.toggleBookmark(); onClose() },
        MI(if (s.b("desktop")) Icons.Filled.Check else Icons.Filled.Info, "Версия для ПК") {
            s["desktop"] = if (s.b("desktop")) 0f else 1f; b.applyDesktop(); onClose()
        },
        MI(Icons.AutoMirrored.Filled.ArrowForward, "Вперёд") { b.current.web?.goForward(); onClose() },
        MI(Icons.Filled.Refresh, "Обновить") { b.current.web?.reload(); onClose() },
        MI(Icons.Filled.Settings, "Настройки") { onClose(); onSettings() }
    )
    Glass(
        modifier.width(s["menuW"].dp).graphicsLayer {
            transformOrigin = TransformOrigin(1f, if (bottom) 1f else 0f)
            val k = lerp(0.2f, 1f, m)
            scaleX = k; scaleY = k
            alpha = (m * 2f).coerceIn(0f, 1f)
        },
        corner = s["menuR"].dp, align = Alignment.TopStart
    ) {
        Column(Modifier.padding(8.dp)) {
            items.forEachIndexed { i, item ->
                val t = ((m - 0.1f - i * 0.05f) / 0.45f).coerceIn(0f, 1f)
                Row(
                    Modifier.fillMaxWidth()
                        .graphicsLayer { alpha = t; translationY = (1f - t) * 28f }
                        .clip(RoundedCornerShape(20.dp))
                        .clickable { item.act() }
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(item.icon, null, Modifier.size(20.dp), tint = ink)
                    Spacer(Modifier.width(12.dp))
                    Text(item.label, color = ink, fontSize = 16.sp)
                }
            }
        }
    }
}

@Composable
fun Suggest(b: Browser, s: S, dark: Boolean, show: Boolean, query: String, bottom: Boolean, onPick: (String) -> Unit) {
    val a by animateFloatAsState(if (show) 1f else 0f, s.springF(), label = "sugg")
    if (a < 0.01f && !show) return
    val ink = if (dark) Color.White else Color(0xFF16161A)
    val q = query.trim()
    val rows = buildList {
        if (q.isNotEmpty()) add(Icons.Filled.Search to q)
        (b.bookmarks + b.history).distinct()
            .filter { q.isEmpty() || it.contains(q, ignoreCase = true) }
            .take(5).forEach { add((if (b.bookmarks.contains(it)) Icons.Filled.Star else Icons.Filled.Refresh) to it) }
    }
    if (rows.isEmpty()) return
    Glass(
        Modifier.fillMaxWidth().padding(horizontal = s["barM"].dp).graphicsLayer {
            transformOrigin = TransformOrigin(0.5f, if (bottom) 1f else 0f)
            val k = lerp(0.88f, 1f, a)
            scaleX = k; scaleY = k; alpha = a.coerceIn(0f, 1f)
        },
        corner = s["menuR"].dp, align = Alignment.TopStart
    ) {
        Column(Modifier.padding(8.dp)) {
            rows.forEach { (ic, text) ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).clickable { onPick(text) }
                        .padding(horizontal = 14.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(ic, null, Modifier.size(18.dp), tint = ink.copy(alpha = 0.7f))
                    Spacer(Modifier.width(12.dp))
                    Text(text, color = ink, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
fun Overview(
    b: Browser, s: S, dark: Boolean, p: Float, slots: MutableMap<Int, Rect>, grid: LazyGridState, open: Boolean,
    onPick: (Int) -> Unit, onNew: () -> Unit, onDone: () -> Unit
) {
    val d = LocalDensity.current
    val ink = if (dark) Color.White else Color(0xFF16161A)
    val statusTop = with(d) { WindowInsets.statusBars.getTop(d).toDp() }
    val barH = s["barH"].dp
    val cols = s.i("cols").coerceIn(1, 3)
    Box(
        Modifier.fillMaxSize().then(
            if (open) Modifier.clickable(
                interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                indication = null
            ) { } else Modifier
        )
    ) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(cols), state = grid,
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = statusTop + 16.dp, bottom = 150.dp),
            verticalArrangement = Arrangement.spacedBy(s["tabGap"].dp),
            horizontalArrangement = Arrangement.spacedBy(s["tabGap"].dp),
            modifier = Modifier.fillMaxSize()
        ) {
            itemsIndexed(b.tabs, key = { _, t -> t.id }) { i, t ->
                TabCard(t, i == b.cur, p, s, slots, onClick = { onPick(i) }, onClose = { slots.remove(t.id); b.closeTab(t.id) })
            }
        }
        Row(
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(s["barM"].dp)
                .graphicsLayer { translationY = (1f - p.coerceIn(0f, 1f)) * 220f; alpha = p.coerceIn(0f, 1f) }
                .fillMaxWidth().height(barH),
            horizontalArrangement = Arrangement.spacedBy(s["gap"].dp)
        ) {
            Glass(Modifier.size(barH), corner = barH / 2, onClick = onNew) { Icon(Icons.Filled.Add, null, tint = ink) }
            Glass(Modifier.weight(1f).fillMaxHeight(), corner = barH / 2) {
                val n = b.tabs.size
                Text(
                    "$n " + (if (n == 1) "вкладка" else if (n < 5) "вкладки" else "вкладок"),
                    color = ink, fontWeight = FontWeight.SemiBold, fontSize = 15.sp
                )
            }
            Glass(Modifier.size(barH), corner = barH / 2, onClick = onDone, tintOverride = ACCENT.copy(alpha = 0.88f)) {
                Icon(Icons.Filled.Check, null, tint = Color.White)
            }
        }
    }
}

@Composable
fun LazyGridItemScope.TabCard(
    t: Tab, current: Boolean, p: Float, s: S, slots: MutableMap<Int, Rect>, onClick: () -> Unit, onClose: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val dx = remember { Animatable(0f) }
    val shape = RoundedCornerShape(s["tabR"].dp)
    val appear = if (current) ((p - 0.85f) / 0.15f).coerceIn(0f, 1f) else p.coerceIn(0f, 1f)
    Box(
        Modifier.animateItem()
            .aspectRatio(s["tabAsp"].coerceAtLeast(0.3f))
            .onGloballyPositioned { slots[t.id] = it.boundsInRoot() }
            .graphicsLayer {
                translationX = dx.value
                rotationZ = dx.value / 70f
                alpha = appear * (1f - (abs(dx.value) / 520f).coerceIn(0f, 1f))
                if (!current) {
                    val k = 0.82f + 0.18f * p.coerceIn(0f, 1f)
                    scaleX = k; scaleY = k
                }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragEnd = {
                        scope.launch {
                            if (abs(dx.value) > 150f) {
                                dx.animateTo(sign(dx.value) * 1300f, tween(200))
                                onClose()
                            } else dx.animateTo(0f, spring(0.6f, 320f))
                        }
                    },
                    onDragCancel = { scope.launch { dx.animateTo(0f) } },
                    onHorizontalDrag = { ch, amt -> ch.consume(); scope.launch { dx.snapTo(dx.value + amt) } }
                )
            }
            .clip(shape)
            .background(Brush.linearGradient(CARD_GRADS[t.id % CARD_GRADS.size]))
            .then(if (current) Modifier.border(2.5.dp, ACCENT, shape) else Modifier)
            .clickable(onClick = onClick)
    ) {
        t.thumb?.let {
            Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alignment = Alignment.TopCenter)
        }
        Box(
            Modifier.align(Alignment.BottomStart).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.6f))))
                .padding(start = 12.dp, end = 12.dp, top = 28.dp, bottom = 10.dp)
        ) {
            Text(t.label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(
            Modifier.align(Alignment.TopEnd).padding(8.dp).size(28.dp).clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.42f))
                .clickable { scope.launch { dx.animateTo(-1300f, tween(220)); onClose() } },
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Filled.Close, null, Modifier.size(15.dp), tint = Color.White) }
    }
}

private val FAVS = listOf(
    "Google" to "https://google.com", "YouTube" to "https://youtube.com",
    "Википедия" to "https://ru.wikipedia.org", "GitHub" to "https://github.com",
    "Яндекс" to "https://ya.ru", "Reddit" to "https://reddit.com",
    "Хабр" to "https://habr.com", "Telegram" to "https://web.telegram.org"
)

@Composable
fun StartPage(b: Browser, dark: Boolean, topPad: androidx.compose.ui.unit.Dp) {
    val ink = if (dark) Color.White else Color(0xFF16161A)
    val inf = rememberInfiniteTransition(label = "orbs")
    val t by inf.animateFloat(0f, 6.2832f, infiniteRepeatable(tween(26000, easing = LinearEasing)), label = "t")
    val tiles = FAVS + b.bookmarks.take(8).map { hostOf(it) to it }
    Box(Modifier.fillMaxSize().background(if (dark) Color(0xFF0C0C12) else Color(0xFFF3F1F7))) {
        Canvas(Modifier.fillMaxSize()) {
            fun orb(cx: Float, cy: Float, r: Float, c: Color) = drawCircle(
                Brush.radialGradient(listOf(c, Color.Transparent), center = Offset(cx, cy), radius = r),
                radius = r, center = Offset(cx, cy)
            )
            orb(size.width * (0.25f + 0.10f * sin(t)), size.height * (0.22f + 0.05f * cos(t)), size.width * 0.75f, Color(0xFFFF7A59).copy(alpha = 0.7f))
            orb(size.width * (0.85f + 0.08f * cos(t * 1.3f)), size.height * (0.50f + 0.06f * sin(t)), size.width * 0.85f, Color(0xFF6C5CFF).copy(alpha = 0.65f))
            orb(size.width * (0.35f + 0.1f * sin(t * 0.7f)), size.height * (0.88f + 0.04f * cos(t)), size.width * 0.8f, Color(0xFF22D3B6).copy(alpha = 0.6f))
        }
        Column(Modifier.fillMaxSize().padding(top = topPad + 24.dp, start = 24.dp, end = 24.dp)) {
            Text("Избранное", color = ink, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(18.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                items(tiles) { f ->
                    Column(
                        Modifier.clip(RoundedCornerShape(16.dp)).clickable { b.navigate(f.second) },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier.size(62.dp).clip(RoundedCornerShape(19.dp))
                                .background(Brush.linearGradient(CARD_GRADS[(f.first.length + f.first.first().code) % CARD_GRADS.size])),
                            contentAlignment = Alignment.Center
                        ) { Text(f.first.first().uppercase(), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold) }
                        Spacer(Modifier.height(6.dp))
                        Text(f.first, color = ink, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}
