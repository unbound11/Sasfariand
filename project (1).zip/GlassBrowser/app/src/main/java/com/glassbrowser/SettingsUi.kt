package com.glassbrowser

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

private fun fmt(v: Float): String =
    if (v >= 100f || v == v.toInt().toFloat()) v.toInt().toString() else "%.2f".format(v)

@Composable
fun SettingsScreen(s: S, dark: Boolean, onClose: () -> Unit) {
    val bg = if (dark) Color(0xFF0D0D11) else Color(0xFFF2F2F7)
    val ink = if (dark) Color.White else Color(0xFF16161A)
    val penv = rememberGlassEnv(s, dark)
    val groups = remember { PARAMS.groupBy { it.group } }

    Column(Modifier.fillMaxSize().background(bg)) {
        // ---------- Живое превью: стекло над яркой картинкой ----------
        Box(Modifier.fillMaxWidth().height(290.dp)) {
            Box(Modifier.fillMaxSize().glassSource(penv)) {
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.linearGradient(listOf(Color(0xFFFF7A59), Color(0xFFFF3D81), Color(0xFF6C5CFF), Color(0xFF18C8E0)))
                    )
                )
                Row(Modifier.fillMaxSize()) {
                    repeat(16) {
                        Box(
                            Modifier.weight(1f).fillMaxHeight()
                                .background(if (it % 2 == 0) Color.White.copy(alpha = 0.14f) else Color.Black.copy(alpha = 0.10f))
                        )
                    }
                }
                Column(Modifier.fillMaxSize().statusBarsPadding().padding(top = 70.dp, start = 18.dp)) {
                    Text("Liquid Glass", color = Color.White, fontSize = 46.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Liquid Glass Liquid Glass", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                }
            }
            CompositionLocalProvider(LocalGlass provides penv) {
                Column(
                    Modifier.fillMaxSize().statusBarsPadding().padding(14.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Glass(Modifier.size(44.dp), corner = 22.dp, onClick = onClose) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = ink)
                        }
                        Glass(Modifier.height(44.dp).width(104.dp), corner = 22.dp, onClick = { s.reset() }) {
                            Text("Сбросить всё", color = ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    Row(Modifier.fillMaxWidth().height(s["barH"].dp), horizontalArrangement = Arrangement.spacedBy(s["gap"].dp)) {
                        Glass(Modifier.size(s["barH"].dp), corner = s["barH"].dp / 2, onClick = {}) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = ink)
                        }
                        Glass(Modifier.weight(1f).fillMaxHeight(), corner = s["barH"].dp / 2, onClick = {}) {
                            Text("apple.com", color = ink, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                        }
                        Glass(Modifier.size(s["barH"].dp), corner = s["barH"].dp / 2, onClick = {}) {
                            Icon(Icons.Filled.MoreVert, null, Modifier.rotate(90f), tint = ink)
                        }
                    }
                }
            }
        }

        // ---------- Все параметры ----------
        LazyColumn(
            Modifier.fillMaxSize().navigationBarsPadding(),
            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 6.dp, bottom = 40.dp)
        ) {
            groups.forEach { (g, ps) ->
                item(key = "h_$g") {
                    Row(
                        Modifier.fillMaxWidth().padding(top = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(g, color = ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        TextButton(onClick = { s.reset(g) }) { Text("Сбросить") }
                    }
                }
                items(ps, key = { it.key }) { p -> ParamRow(s, p, ink) }
            }
        }
    }
}

@Composable
fun ParamRow(s: S, p: P, ink: Color) {
    Column(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        when (p.kind) {
            K.SLIDER -> {
                val v = s[p.key]
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(p.label, color = ink, fontSize = 15.sp, modifier = Modifier.weight(1f))
                    Text(fmt(v) + (if (p.unit.isEmpty()) "" else " " + p.unit), color = ink.copy(alpha = 0.6f), fontSize = 14.sp)
                }
                val steps = if (p.step > 0f) ((p.max - p.min) / p.step).roundToInt() - 1 else 0
                Slider(
                    value = v,
                    onValueChange = { s[p.key] = if (p.step > 0f) it.roundToInt().toFloat() else it },
                    valueRange = p.min..p.max,
                    steps = steps
                )
            }
            K.TOGGLE -> Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(p.label, color = ink, fontSize = 15.sp, modifier = Modifier.weight(1f))
                Switch(checked = s.b(p.key), onCheckedChange = { s[p.key] = if (it) 1f else 0f })
            }
            K.CHOICE -> {
                Text(p.label, color = ink, fontSize = 15.sp)
                Spacer(Modifier.height(6.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    p.opts.forEachIndexed { i, o ->
                        val sel = s.i(p.key) == i
                        Box(
                            Modifier.clip(RoundedCornerShape(50))
                                .background(if (sel) ACCENT else ink.copy(alpha = 0.1f))
                                .clickable { s[p.key] = i.toFloat() }
                                .padding(horizontal = 16.dp, vertical = 9.dp)
                        ) {
                            Text(o, color = if (sel) Color.White else ink, fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }
}
