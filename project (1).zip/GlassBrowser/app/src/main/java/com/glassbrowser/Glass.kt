package com.glassbrowser

import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import android.graphics.RenderEffect as AndroidRenderEffect
import androidx.compose.ui.graphics.RenderEffect as ComposeRenderEffect

/**
 * Окружение стекла: "источник" — слой, в который записывается всё, что находится ПОД стеклом
 * (страница). Каждый стеклянный элемент рисует свой кусок этого слоя, размытый и искажённый.
 */
class GlassEnv(val s: S, val source: GraphicsLayer) {
    var origin by mutableStateOf(Offset.Zero)
    var dark by mutableStateOf(false)
    val tick = mutableIntStateOf(0)
    fun bump() {
        tick.intValue = tick.intValue + 1
    }
}

val LocalGlass = compositionLocalOf<GlassEnv> { error("GlassEnv not provided") }

@Composable
fun rememberGlassEnv(s: S, dark: Boolean): GlassEnv {
    val layer = rememberGraphicsLayer()
    val env = remember(layer) { GlassEnv(s, layer) }
    SideEffect { env.dark = dark }
    return env
}

/** Помечает содержимое, которое должно просвечивать сквозь стекло. Не кладите Glass внутрь! */
fun Modifier.glassSource(env: GlassEnv): Modifier = this
    .onGloballyPositioned { env.origin = it.positionInRoot() }
    .drawWithContent {
        if (env.s.b("real") && Build.VERSION.SDK_INT >= 31) {
            env.source.record(this, layoutDirection, IntSize(size.width.toInt(), size.height.toInt())) {
                this@drawWithContent.drawContent()
            }
            drawLayer(env.source)
        } else {
            drawContent()
        }
    }

private const val AGSL = """
uniform shader content;
uniform float2 size;
uniform float radius;
uniform float strength;
uniform float edge;
half4 main(float2 p) {
    float2 c = p - size * 0.5;
    float2 q = abs(c) - (size * 0.5 - float2(radius));
    float d = length(max(q, float2(0.0))) + min(max(q.x, q.y), 0.0) - radius;
    float k = clamp(1.0 + d / edge, 0.0, 1.0);
    k = k * k;
    float2 n;
    if (q.x > 0.0 && q.y > 0.0) {
        n = normalize(float2(sign(c.x) * q.x, sign(c.y) * q.y));
    } else if (q.x > q.y) {
        n = float2(sign(c.x), 0.0);
    } else {
        n = float2(0.0, sign(c.y));
    }
    float2 o = n * strength * k;
    half4 a = content.eval(p - o * 0.9);
    half4 b = content.eval(p - o);
    half4 e = content.eval(p - o * 1.1);
    return half4(a.r, b.g, e.b, b.a);
}
"""

@RequiresApi(31)
private fun buildEffect(w: Float, h: Float, r: Float, blur: Float, sat: Float, refr: Float, edge: Float): ComposeRenderEffect {
    var e: AndroidRenderEffect? = null
    if (blur > 0.5f) e = AndroidRenderEffect.createBlurEffect(blur, blur, Shader.TileMode.CLAMP)
    if (Build.VERSION.SDK_INT >= 33 && refr > 0.5f) {
        val sh = RuntimeShader(AGSL)
        sh.setFloatUniform("size", w, h)
        sh.setFloatUniform("radius", minOf(r, minOf(w, h) / 2f))
        sh.setFloatUniform("strength", refr)
        sh.setFloatUniform("edge", edge.coerceAtLeast(1f))
        val se = AndroidRenderEffect.createRuntimeShaderEffect(sh, "content")
        e = if (e == null) se else AndroidRenderEffect.createChainEffect(se, e)
    }
    val cm = ColorMatrix().apply { setSaturation(sat) }
    val cf = ColorMatrixColorFilter(cm)
    val out = if (e == null) AndroidRenderEffect.createColorFilterEffect(cf)
    else AndroidRenderEffect.createColorFilterEffect(cf, e)
    return out.asComposeRenderEffect()
}

@Composable
fun Glass(
    modifier: Modifier = Modifier,
    corner: Dp = 26.dp,
    onClick: (() -> Unit)? = null,
    onLongClick: (() -> Unit)? = null,
    tintOverride: Color? = null,
    align: Alignment = Alignment.Center,
    content: @Composable BoxScope.() -> Unit = {}
) {
    val env = LocalGlass.current
    val s = env.s
    val d = LocalDensity.current
    val shape = RoundedCornerShape(corner)
    val layer = rememberGraphicsLayer()
    var sz by remember { mutableStateOf(IntSize.Zero) }
    var pos by remember { mutableStateOf(Offset.Zero) }
    var pressed by remember { mutableStateOf(false) }
    var touch by remember { mutableStateOf(Offset.Zero) }
    val clickS by rememberUpdatedState(onClick)
    val longS by rememberUpdatedState(onLongClick)
    val ps by animateFloatAsState(if (pressed) s["press"] else 1f, s.springF(), label = "press")
    val specA by animateFloatAsState(if (pressed) 1f else 0f, tween(380), label = "spec")

    val effect: ComposeRenderEffect? = remember(sz, s["blur"], s["sat"], s["refr"], s["edgeW"], d.density) {
        if (Build.VERSION.SDK_INT >= 31 && sz.width > 0 && sz.height > 0)
            buildEffect(
                sz.width.toFloat(), sz.height.toFloat(), with(d) { corner.toPx() },
                s["blur"] * d.density, s["sat"], s["refr"] * d.density, s["edgeW"] * d.density
            )
        else null
    }
    SideEffect {
        layer.clip = true
        if (layer.renderEffect !== effect) layer.renderEffect = effect
    }
    val interactive = onClick != null || onLongClick != null
    val real = s.b("real") && effect != null

    Box(
        modifier
            .graphicsLayer { scaleX = ps; scaleY = ps }
            .shadow(
                (16f * s["shadow"]).dp, shape, clip = false,
                ambientColor = Color.Black.copy(alpha = 0.3f * s["shadow"]),
                spotColor = Color.Black.copy(alpha = 0.45f * s["shadow"])
            )
            .clip(shape)
            .onGloballyPositioned { sz = it.size; pos = it.positionInRoot() }
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val e = awaitPointerEvent(PointerEventPass.Initial)
                        val c = e.changes.firstOrNull()
                        if (c != null && c.pressed) touch = c.position
                    }
                }
            }
            .then(
                if (interactive) Modifier.pointerInput(Unit) {
                    detectTapGestures(
                        onPress = { o -> touch = o; pressed = true; tryAwaitRelease(); pressed = false },
                        onTap = { clickS?.invoke() },
                        onLongPress = { longS?.invoke() }
                    )
                } else Modifier
            )
            .drawWithContent {
                env.tick.intValue // подписка: перерисовка при прокрутке страницы
                if (real) {
                    val off = pos - env.origin
                    layer.record(this, layoutDirection, IntSize(size.width.toInt(), size.height.toInt())) {
                        translate(-off.x, -off.y) { drawLayer(env.source) }
                    }
                    drawLayer(layer)
                }
                val base = if (env.dark) Color(0xFF2B2B33) else Color.White
                val a = (s["tint"] + if (real) 0f else 0.3f).coerceIn(0f, 0.95f)
                drawRect(tintOverride ?: base.copy(alpha = a))
                drawContent()

                val cr = corner.toPx()
                val sheen = s["sheen"]
                if (sheen > 0f) drawRoundRect(
                    Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.38f * sheen), Color.Transparent),
                        startY = 0f, endY = size.height * 0.6f
                    ),
                    cornerRadius = CornerRadius(cr)
                )
                val rim = s["rim"]
                val rw = s["rimW"].dp.toPx()
                if (rim > 0f) drawRoundRect(
                    Brush.linearGradient(
                        listOf(
                            Color.White.copy(alpha = 0.9f * rim),
                            Color.White.copy(alpha = 0.06f * rim),
                            Color.White.copy(alpha = 0.5f * rim)
                        ),
                        start = Offset.Zero, end = Offset(size.width, size.height)
                    ),
                    topLeft = Offset(rw / 2f, rw / 2f),
                    size = Size(size.width - rw, size.height - rw),
                    cornerRadius = CornerRadius((cr - rw / 2f).coerceAtLeast(0f)),
                    style = Stroke(rw)
                )
                val sp = s["spec"]
                if (sp > 0f && specA > 0.01f) {
                    val rr = s["specR"].dp.toPx()
                    drawCircle(
                        Brush.radialGradient(
                            listOf(Color.White.copy(alpha = 0.8f * specA * sp), Color.Transparent),
                            center = touch, radius = rr
                        ),
                        radius = rr, center = touch
                    )
                }
            },
        contentAlignment = align,
        content = content
    )
}
