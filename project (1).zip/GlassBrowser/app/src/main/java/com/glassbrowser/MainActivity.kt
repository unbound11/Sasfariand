package com.glassbrowser

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge

class MainActivity : ComponentActivity() {
    private lateinit var browser: Browser

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val s = S(this)
        browser = Browser(this, s)
        handle(intent)
        setContent { App(browser, s) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        val u = i?.dataString
        if (u != null) browser.openInNewTab(u)
    }

    override fun onPause() {
        super.onPause()
        browser.save()
    }
}
